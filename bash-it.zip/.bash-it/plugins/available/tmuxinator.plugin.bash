cite about-plugin
about-plugin 'sources tmuxinator script if available'

[[ -s "$HOME/.tmuxinator/scripts/tmuxinator" ]] && . "$HOME/.tmuxinator/scripts/tmuxinator"
