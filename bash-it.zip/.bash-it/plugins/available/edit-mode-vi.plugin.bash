cite about-plugin
about-plugin 'Enable vi editing mode'

set -o vi
