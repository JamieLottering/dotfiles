[[ -x "$(which jungle)" ]] && eval "$(_JUNGLE_COMPLETE=source jungle)"
