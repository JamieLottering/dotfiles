cite 'about-alias'
about-alias 'Tmux terminal multiplexer'

alias txl='tmux ls'
alias txn='tmux new -s'
alias txa='tmux a -t'
